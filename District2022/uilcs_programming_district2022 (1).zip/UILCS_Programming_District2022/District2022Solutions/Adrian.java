public class Adrian {

	public static void main(String[] args) {
		System.out.println("JAVA");
		System.out.println("PYTHON");
		System.out.println("SWIFT");
		System.out.println("ADA");
		System.out.println("C");
		System.out.println("C++");
		System.out.println("COBOL");
		System.out.println("FORTRAN");
		System.out.println("ALGOL");
		System.out.println("BASIC");
		System.out.println("DELPHI");
		System.out.println("PASCAL");
		System.out.println("PL1");
		System.out.println("JAVASCRIPT");
	}
}
